# eSports Tycoon Empire — Electron + Phaser 3 + TypeScript Port

## Обзор
Полный порт Unity-игры «eSports Tycoon Empire» v1.3.3 на веб-стек:
- **Electron** — десктопное приложение
- **Phaser 3** — игровой движок, сцены
- **TypeScript** — строгая типизация
- **Zustand** — глобальное состояние (замена GameState синглтона)
- **bitecs** — ECS (Entity Component System)
- **Chart.js, GSAP, iziToast, Shepherd.js, SortableJS** — UI
- **Howler.js** — звук
- **TensorFlow.js** — ML-прогнозирование матчей
- **@telazer/steamworks** — Steam API (достижения, лидерборды, облако)
- **Firebase** — облачные сохранения
- **JSZip + fengari** — система модов

---

## Требования

- **Node.js** ≥ 20.x
- **npm** ≥ 10.x
- **Git**
- (Опционально) **Steam** клиент для тестирования Steam-функций

---

## Установка и запуск

```bash
# 1. Клонировать репозиторий
git clone https://github.com/your-org/esports-tycoon-empire.git
cd esports-tycoon-empire

# 2. Установить зависимости
npm install
npm run build
npm start

# 5. Режим разработки (watch + hot-reload)
npm run dev
```

---

## Сборка дистрибутива

```bash
# Windows (.exe + installer)
npm run build:prod

# Файл появится в папке release/
```

---

## Настройка Steam

1. Зарегистрируйте приложение на [Steamworks](https://partner.steamgames.com/)
2. Получите **App ID**
3. Откройте `electron-main.js`, замените:
   ```js
   const STEAM_APP_ID = 480; // ← заменить на ваш App ID
   ```
4. Скачайте `steam_appid.txt` из Steamworks и положите в корень проекта:
   ```
   480
   ```
5. Добавьте достижения в Steamworks Developer > Achievements:
   - `ACH_FIRST_WIN` — Первая победа
   - `ACH_CHAMPION` — Первый чемпионат
   - `ACH_PERFECT_SEASON` — Идеальный сезон (без поражений)
   - `ACH_TRANSFER_KING` — 10 трансферов
   - `ACH_MILLIONAIRE` — $10,000,000 бюджет
   - (и другие из `src/services/SteamService.ts`)

---

## Настройка Firebase

1. Создайте проект на [Firebase Console](https://console.firebase.google.com/)
2. Включите **Firestore** и **Authentication** (Email/Password или Anonymous)
3. Скопируйте конфиг и вставьте в `src/services/FirebaseService.ts`:
   ```ts
   const firebaseConfig = {
     apiKey: "YOUR_API_KEY",
     authDomain: "YOUR_PROJECT.firebaseapp.com",
     projectId: "YOUR_PROJECT_ID",
     storageBucket: "YOUR_PROJECT.appspot.com",
     messagingSenderId: "YOUR_SENDER_ID",
     appId: "YOUR_APP_ID"
   };
   ```
4. Правила Firestore (разрешить чтение/запись для авторизованных):
   ```
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /saves/{userId}/{document=**} {
         allow read, write: if request.auth != null && request.auth.uid == userId;
       }
     }
   }
   ```

---

## Настройка ML-прогнозирования

TensorFlow.js используется для предсказания исходов матчей. Модель — заглушка LSTM.

```bash
# Обучить модель (опционально, требует данных)
# Поместите данные матчей в data/match-history.json
# Запустите:
node scripts/train-model.js
```

Модель сохранится в `public/models/match-predictor/`. При первом запуске без обученной модели используется статистическое предсказание.

---

## Система модов

1. Моды — это `.zip` архивы в папке `%AppData%/esports-tycoon/mods/`
2. Структура мода:
   ```
   my-mod.zip
   ├── mod.json         { "name": "My Mod", "version": "1.0", "entry": "main.lua" }
   ├── main.lua         -- Lua скрипт (выполняется через fengari)
   └── data/
       └── players.lua  -- Дополнительные игроки
   ```
3. В игре: вкладка **Моды** → кнопка «Открыть папку модов» → поместить `.zip` → «Перезагрузить моды»

---

## Структура проекта

```
esports-tycoon/
├── electron-main.js        # Главный процесс Electron
├── preload.js              # contextBridge API
├── index.html              # Точка входа
├── style.css               # Все стили
├── package.json
├── tsconfig.json
├── webpack.config.js
└── src/
    ├── main.ts             # Инициализация Phaser + сервисов
    ├── scenes/             # Phaser сцены
    ├── store/              # Zustand store (GameState)
    ├── ecs/                # bitecs World + компоненты + системы
    ├── models/             # Классы данных (Player, Team, ...)
    ├── engine/             # MatchEngine, WeaponDatabase, ...
    ├── services/           # Save, Steam, Firebase, Sound, ...
    ├── ui/                 # UIManager, Tutorial, Effects, ...
    ├── localization/       # i18next, 13 языков
    ├── features/           # Дополнительные фичи
    └── utils/              # Форматтеры, хелперы
```

---

## Конфигурация защиты кода (JScrambler)

1. Зарегистрируйтесь на [jscrambler.com](https://jscrambler.com)
2. Установите CLI: `npm install -g jscrambler`
3. Создайте `.jscramblerrc` в корне проекта (пример в документации)
4. После сборки: `jscrambler dist/bundle.js`

---

## Поддерживаемые языки

RU, EN, DE, FR, ES, PT, PL, TR, ZH, KO, JA, AR, UK

---

## Лицензия

Проект для личного использования. Steam API — лицензия Valve. Firebase — Google ToS.
